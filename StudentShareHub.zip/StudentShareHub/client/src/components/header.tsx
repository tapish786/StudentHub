import { Button } from "@/components/ui/button";
import { Upload, Menu } from "lucide-react";
import { useState } from "react";
import { ModeToggle } from "@/components/mode-toggle";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm border-b border-border dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary">Tapish</h1>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors">
              Home
            </a>
            <a href="#materials" className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors">
              Browse Notes
            </a>
            <a href="#upload" className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors">
              Upload
            </a>
          </nav>

          <div className="flex items-center space-x-4">
            <ModeToggle />
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={() => document.getElementById('file-upload')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload Notes
            </Button>
            <div className="w-8 h-8 bg-muted rounded-full"></div>
          </div>

          {/* Mobile menu button */}
          <button 
            className="md:hidden text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col space-y-2">
              <a href="#" className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors">
                Home
              </a>
              <a href="#materials" className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors">
                Browse Notes
              </a>
              <a href="#upload" className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium transition-colors">
                Upload
              </a>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
