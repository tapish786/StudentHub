import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

interface SearchFilterProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedSubject: string;
  onSubjectChange: (subject: string) => void;
  subjects: string[];
}

export default function SearchFilter({
  searchQuery,
  onSearchChange,
  selectedSubject,
  onSubjectChange,
  subjects,
}: SearchFilterProps) {
  return (
    <section className="py-8 bg-white dark:bg-gray-900 border-t border-border dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-6 items-center">
          {/* Search Bar */}
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-muted-foreground" />
            </div>
            <Input
              id="search"
              type="text"
              placeholder="Search notes by subject, topic, or keywords..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
          
          {/* Filter Buttons */}
          <div className="flex flex-wrap gap-3">
            {subjects.map((subject) => (
              <Button
                key={subject}
                variant={selectedSubject === subject ? "default" : "outline"}
                size="sm"
                onClick={() => onSubjectChange(subject)}
                className={
                  selectedSubject === subject
                    ? "bg-primary text-primary-foreground"
                    : "bg-white text-foreground border-border hover:bg-muted"
                }
              >
                {subject}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
