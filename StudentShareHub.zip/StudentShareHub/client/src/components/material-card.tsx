import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Eye, FileText, FileImage, Presentation, File } from "lucide-react";
import { Material } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface MaterialCardProps {
  material: Material;
}

export default function MaterialCard({ material }: MaterialCardProps) {
  const { toast } = useToast();

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return <FileText className="h-5 w-5 text-red-500" />;
    if (fileType.includes('word')) return <FileText className="h-5 w-5 text-blue-500" />;
    if (fileType.includes('powerpoint') || fileType.includes('presentation')) return <Presentation className="h-5 w-5 text-orange-500" />;
    if (fileType.includes('image')) return <FileImage className="h-5 w-5 text-green-500" />;
    return <File className="h-5 w-5 text-gray-500" />;
  };

  const getFileTypeLabel = (fileType: string) => {
    if (fileType.includes('pdf')) return 'PDF';
    if (fileType.includes('word')) return 'DOC';
    if (fileType.includes('powerpoint') || fileType.includes('presentation')) return 'PPT';
    if (fileType.includes('image')) return 'IMG';
    return 'FILE';
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - d.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return '1 day ago';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 14) return '1 week ago';
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return d.toLocaleDateString();
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const response = await fetch(`/api/materials/${material.id}/download`);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = material.originalName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download started",
        description: `Downloading ${material.originalName}`,
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Failed to download the file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePreview = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Open file in new tab for preview
    window.open(`/api/files/${material.filename}`, '_blank');
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-border dark:border-gray-600 p-4 hover:shadow-md transition-shadow cursor-pointer">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          {getFileIcon(material.fileType)}
          <Badge variant="secondary" className="text-xs">
            {getFileTypeLabel(material.fileType)}
          </Badge>
        </div>
        <div className="text-xs text-muted-foreground">
          {formatFileSize(material.fileSize)}
        </div>
      </div>
      
      <h4 className="font-semibold text-foreground mb-2 line-clamp-2" title={material.title}>
        {material.title}
      </h4>
      <p className="text-sm text-muted-foreground mb-3">
        {material.subject} {material.semester && `• ${material.semester}`}
      </p>
      
      {material.description && (
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
          {material.description}
        </p>
      )}
      
      <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
        <span>By {material.uploadedBy}</span>
        <span>{formatDate(material.uploadedAt)}</span>
      </div>
      
      <div className="flex space-x-2">
        <Button 
          size="sm" 
          className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={handleDownload}
        >
          <Download className="mr-1 h-3 w-3" />
          Download
        </Button>
        <Button 
          size="sm" 
          variant="outline"
          className="bg-muted text-muted-foreground hover:bg-muted/80"
          onClick={handlePreview}
        >
          <Eye className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}
