import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import Footer from "@/components/footer";
import FileUpload from "@/components/file-upload";
import SearchFilter from "@/components/search-filter";
import MaterialCard from "@/components/material-card";
import { Button } from "@/components/ui/button";
import { Material } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("All Subjects");

  const { data: materials = [], isLoading } = useQuery<Material[]>({
    queryKey: ["/api/materials", { search: searchQuery, subject: selectedSubject }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", searchQuery);
      if (selectedSubject !== "All Subjects") params.append("subject", selectedSubject);
      
      const response = await fetch(`/api/materials?${params}`);
      if (!response.ok) throw new Error("Failed to fetch materials");
      return response.json();
    },
  });

  const subjects = ["All Subjects", "Mathematics", "Science", "Engineering", "Business", "Computer Science", "Physics", "Chemistry", "Economics"];

  return (
    <div className="min-h-screen bg-background dark:bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-white dark:bg-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-foreground mb-6">
                Share Knowledge,<br />
                <span className="text-primary">Build Success</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Connect with your academic community. Upload your study materials and access resources shared by fellow students to excel in your studies.
              </p>
              
              <FileUpload />
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Students collaborating on study materials" 
                className="rounded-xl shadow-lg w-full h-auto" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <SearchFilter
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedSubject={selectedSubject}
        onSubjectChange={setSelectedSubject}
        subjects={subjects}
      />

      {/* Materials Section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-2xl font-bold text-foreground">
              {searchQuery ? `Search Results for "${searchQuery}"` : "Recently Shared Materials"}
            </h3>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm border border-border p-4 animate-pulse">
                  <div className="h-6 bg-muted rounded mb-3"></div>
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-4 bg-muted rounded mb-3 w-3/4"></div>
                  <div className="flex space-x-2">
                    <div className="flex-1 h-8 bg-muted rounded"></div>
                    <div className="w-10 h-8 bg-muted rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : materials.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">📚</div>
              <h3 className="text-xl font-semibold mb-2">
                {searchQuery || selectedSubject !== "All Subjects" ? "No materials found" : "No materials yet"}
              </h3>
              <p className="text-muted-foreground mb-6">
                {searchQuery || selectedSubject !== "All Subjects" 
                  ? "Try adjusting your search or filter criteria."
                  : "Be the first to share study materials with the community!"
                }
              </p>
              {!searchQuery && selectedSubject === "All Subjects" && (
                <Button onClick={() => document.getElementById('file-upload')?.scrollIntoView({ behavior: 'smooth' })}>
                  Upload First Material
                </Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {materials.map((material) => (
                <MaterialCard key={material.id} material={material} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-2xl font-bold text-foreground mb-4">Join Our Growing Community</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Thousands of students are already sharing knowledge and accelerating their academic success.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="p-6">
              <div className="text-4xl font-bold text-primary mb-2">{materials.length}</div>
              <div className="text-muted-foreground font-medium">Study Materials Shared</div>
            </div>
            <div className="p-6">
              <div className="text-4xl font-bold text-secondary mb-2">
                {new Set(materials.map(m => m.uploadedBy)).size}
              </div>
              <div className="text-muted-foreground font-medium">Active Students</div>
            </div>
            <div className="p-6">
              <div className="text-4xl font-bold text-accent mb-2">
                {new Set(materials.map(m => m.subject)).size}
              </div>
              <div className="text-muted-foreground font-medium">Subjects Covered</div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 bg-gradient-to-r from-primary to-blue-700">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-white mb-6">Ready to Share Your Knowledge?</h3>
          <p className="text-xl text-blue-100 mb-8">
            Upload your first study material and help fellow students succeed in their academic journey.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-white text-primary hover:bg-gray-100"
              onClick={() => document.getElementById('file-upload')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Upload Materials
            </Button>
            <Button 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-primary"
              onClick={() => document.getElementById('search')?.focus()}
            >
              Browse Notes
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
