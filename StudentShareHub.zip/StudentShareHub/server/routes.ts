import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertMaterialSchema } from "@shared/schema";

// Extend Request type to include file
interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

const uploadsDir = path.join(process.cwd(), "uploads");

// Ensure uploads directory exists
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage_multer = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage_multer,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Please upload PDF, DOC, PPT, or image files.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all materials
  app.get("/api/materials", async (req, res) => {
    try {
      const { search, subject } = req.query;
      
      let materials;
      
      if (search && typeof search === 'string') {
        materials = await storage.searchMaterials(search);
      } else if (subject && typeof subject === 'string') {
        materials = await storage.getMaterialsBySubject(subject);
      } else {
        materials = await storage.getMaterials();
      }
      
      res.json(materials);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch materials" });
    }
  });

  // Get single material
  app.get("/api/materials/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const material = await storage.getMaterial(id);
      
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }
      
      res.json(material);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch material" });
    }
  });

  // Upload material
  app.post("/api/materials", upload.single('file'), async (req: MulterRequest, res) => {
    try {
      console.log("Upload request received:", { file: req.file, body: req.body });
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { title, description, subject, semester, uploadedBy } = req.body;

      // Validate required fields
      if (!title || !subject || !uploadedBy) {
        // Clean up uploaded file if validation fails
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ message: "Title, subject, and uploader name are required" });
      }

      const materialData = {
        title,
        description: description || null,
        filename: req.file.filename,
        originalName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        subject,
        semester: semester || null,
        uploadedBy,
      };

      // Validate with schema
      const validatedData = insertMaterialSchema.parse(materialData);
      
      const material = await storage.createMaterial(validatedData);
      res.status(201).json(material);
    } catch (error) {
      // Clean up uploaded file if there's an error
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to upload material" });
      }
    }
  });

  // Download material
  app.get("/api/materials/:id/download", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const material = await storage.getMaterial(id);
      
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }
      
      const filePath = path.join(uploadsDir, material.filename);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found on server" });
      }
      
      res.download(filePath, material.originalName);
    } catch (error) {
      res.status(500).json({ message: "Failed to download material" });
    }
  });

  // Serve uploaded files for preview
  app.get("/api/files/:filename", (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadsDir, filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found" });
    }
    
    res.sendFile(filePath);
  });

  const httpServer = createServer(app);
  return httpServer;
}
