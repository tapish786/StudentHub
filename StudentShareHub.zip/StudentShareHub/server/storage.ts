import { users, materials, type User, type InsertUser, type Material, type InsertMaterial } from "@shared/schema";
import { db } from "./db";
import { eq, ilike, or, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getMaterials(): Promise<Material[]>;
  getMaterial(id: number): Promise<Material | undefined>;
  createMaterial(material: InsertMaterial): Promise<Material>;
  searchMaterials(query: string): Promise<Material[]>;
  getMaterialsBySubject(subject: string): Promise<Material[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getMaterials(): Promise<Material[]> {
    return await db
      .select()
      .from(materials)
      .orderBy(desc(materials.uploadedAt));
  }

  async getMaterial(id: number): Promise<Material | undefined> {
    const [material] = await db.select().from(materials).where(eq(materials.id, id));
    return material || undefined;
  }

  async createMaterial(insertMaterial: InsertMaterial): Promise<Material> {
    const [material] = await db
      .insert(materials)
      .values({
        ...insertMaterial,
        description: insertMaterial.description || null,
        semester: insertMaterial.semester || null,
      })
      .returning();
    return material;
  }

  async searchMaterials(query: string): Promise<Material[]> {
    return await db
      .select()
      .from(materials)
      .where(
        or(
          ilike(materials.title, `%${query}%`),
          ilike(materials.description, `%${query}%`),
          ilike(materials.subject, `%${query}%`),
          ilike(materials.originalName, `%${query}%`)
        )
      )
      .orderBy(desc(materials.uploadedAt));
  }

  async getMaterialsBySubject(subject: string): Promise<Material[]> {
    if (subject === "All Subjects") {
      return this.getMaterials();
    }
    
    return await db
      .select()
      .from(materials)
      .where(ilike(materials.subject, subject))
      .orderBy(desc(materials.uploadedAt));
  }
}

export const storage = new DatabaseStorage();
